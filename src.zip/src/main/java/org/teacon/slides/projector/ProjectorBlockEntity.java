package org.teacon.slides.projector;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.Container;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.HopperBlockEntity;
import net.minecraft.world.level.block.entity.TickableBlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import org.teacon.slides.Slideshow;
import org.teacon.slides.item.ImageItem;

/**
 * 投影仪方块实体
 */
@SuppressWarnings("ConstantConditions")
public final class ProjectorBlockEntity extends BlockEntity implements TickableBlockEntity {

	public SourceType mSourceType = SourceType.URL;
	public String mLocation = "";
	public int mColor = ~0;
	public float mWidth = 1;
	public float mHeight = 1;
	public float mOffsetX = 0;
	public float mOffsetY = 0;
	public float mOffsetZ = 0;
	public boolean mDoubleSided = true;

	public Container mContainer = null;
	public int scanIndex = -1;

	public boolean needInitContainer = true;  // （容器方块模式时）是否需要初始化容器读取信息
	public boolean needHandleReadImage = true;  // （容器方块模式时）是否需要读取图片
	public boolean flipBack = false;  // （容器方块模式时）是否向前翻页

	public boolean mCFromID = false;  // 容器方块模式时
	public String mCLocation = "";  // 容器方块模式时

	public ProjectorBlockEntity() {
		super(Slideshow.PROJECTOR_BLOCK_ENTITY);
	}

	// 尝试从物品堆叠读取
	private boolean tryReadImageItem(ItemStack item) {
		if(item.getItem() instanceof ImageItem && item.hasTag() && item.getTag().contains("location")) {
			this.mCFromID = item.getTag().getBoolean("from_id");
			this.mCLocation = item.getTag().getString("location");
			return true;
		}
		return false;
	}

	private void initContainer() {
		for(int i = 0; i < this.mContainer.getContainerSize(); i++) {
			ItemStack item = this.mContainer.getItem(i);
			if(tryReadImageItem(item)) {
				this.scanIndex = i;
				return;
			}
		}
		this.scanIndex = -1;
		this.mCLocation = "";
	}

	// 读取图片
	public void handleReadImage() {
		if(this.mContainer == null || this.scanIndex < 0) {
			return;
		}
		int size = this.mContainer.getContainerSize();
		if(flipBack) {
			for (int i = size + this.scanIndex - 1; i > this.scanIndex - 1; i--) {
				ItemStack item = this.mContainer.getItem(i % size);
				if (tryReadImageItem(item)) {
					this.scanIndex = i;
					return;
				}
			}
		}
		else {
			for (int i = this.scanIndex + 1; i < size + this.scanIndex + 1; i++) {
				ItemStack item = this.mContainer.getItem(i % size);
				if (tryReadImageItem(item)) {
					this.scanIndex = i;
					return;
				}
			}
		}
		this.scanIndex = -1;
		this.mCLocation = "";
	}

	// 是否可以翻译
	public boolean canFlip() {
		return this.mSourceType == SourceType.ContainerBlock && this.mContainer != null;
	}

	public boolean getFromID() {
		if(this.mSourceType != SourceType.ContainerBlock) {
			return this.mSourceType == SourceType.ResourceID;
		}
		return this.mCFromID;
	}

	public String getLocation() {
		if(this.mSourceType != SourceType.ContainerBlock) {
			return this.mLocation;
		}
		return this.mCLocation;
	}


	@Override
	public CompoundTag save(CompoundTag compoundTag) {
		this.saveCompound(compoundTag);
		return super.save(compoundTag);
	}

	@Override
	public void load(BlockState blockState, CompoundTag compoundTag) {
		this.loadCompound(compoundTag);
		super.load(blockState, compoundTag);
	}

	public void saveCompound(CompoundTag compoundTag) {
		compoundTag.putString("SourceType", switch(mSourceType) {
			case ResourceID -> "resource_id";
			case ContainerBlock -> "container";
			default -> "url";
		});
		compoundTag.putString("ImageLocation", mLocation);
		compoundTag.putInt("Color", mColor);
		compoundTag.putFloat("Width", mWidth);
		compoundTag.putFloat("Height", mHeight);
		compoundTag.putFloat("OffsetX", mOffsetX);
		compoundTag.putFloat("OffsetY", mOffsetY);
		compoundTag.putFloat("OffsetZ", mOffsetZ);
		compoundTag.putBoolean("DoubleSided", mDoubleSided);
		compoundTag.putBoolean("CFromID", mCFromID);
		compoundTag.putString("CLocation", mCLocation);
	}

	public void loadCompound(CompoundTag compoundTag) {
		mSourceType = switch (compoundTag.getString("SourceType")) {
			case "resource_id" -> SourceType.ResourceID;
			case "container" -> SourceType.ContainerBlock;
			default -> SourceType.URL;
		};
		mLocation = compoundTag.getString("ImageLocation");
		mColor = compoundTag.getInt("Color");
		mWidth = compoundTag.getFloat("Width");
		mHeight = compoundTag.getFloat("Height");
		mOffsetX = compoundTag.getFloat("OffsetX");
		mOffsetY = compoundTag.getFloat("OffsetY");
		mOffsetZ = compoundTag.getFloat("OffsetZ");
		mDoubleSided = compoundTag.getBoolean("DoubleSided");
		mCFromID = compoundTag.getBoolean("CFromID");
		mCLocation = compoundTag.getString("CLocation");
	}

	public void sync() {
		if(this.level.isClientSide()) {
			return;
		}
		new ProjectorTagUpdateS2CPacket(this).sendToClient((ServerLevel) this.level);
	}

	@Override
	public void tick() {
		if(level.isClientSide()) {
			return;
		}
		if(this.mSourceType != SourceType.ContainerBlock) {
			return;
		}
		this.mContainer = HopperBlockEntity.getContainerAt(level, this.getBlockPos().below(1));
		if(this.mContainer == null) {
			return;
		}
		if(this.needInitContainer) {
			this.initContainer();
			this.needInitContainer = false;
			this.setChanged();
			this.sync();
			return;
		}
		if(this.needHandleReadImage) {
			if(this.scanIndex < 0) {
				this.initContainer();
				return;
			}
			this.handleReadImage();
			this.setChanged();
			this.sync();
			this.needHandleReadImage = false;
			this.flipBack = false;
		}
	}

	@Override
	public CompoundTag getUpdateTag() {
		return this.save(new CompoundTag());
	}

	@Override
	public boolean onlyOpCanSetNbt() {
		return true;
	}
}
