package org.teacon.slides.projector;

import com.mojang.authlib.GameProfile;
import io.netty.buffer.Unpooled;
import net.minecraft.nbt.ByteTag;
import net.minecraft.nbt.StringTag;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.ItemStack;
import org.teacon.slides.RegistryClient;
import org.teacon.slides.Slideshow;
import org.teacon.slides.util.Utilities;

/**
 * 投影仪导出的C2S数据包控制
 */
public class ProjectorExportC2SPacket {

    private final boolean mFromID;
    private final String mLocation;

    public ProjectorExportC2SPacket(boolean fromID, String location) {
        mFromID = fromID;
        mLocation = location;
    }

    public ProjectorExportC2SPacket(FriendlyByteBuf buf){
        mFromID = buf.readBoolean();
        mLocation = buf.readUtf();
    }

    public void sendToServer() {
        FriendlyByteBuf buffer = new FriendlyByteBuf(Unpooled.buffer());
        buffer.writeBoolean(mFromID);
        buffer.writeUtf(mLocation);
        RegistryClient.sendToServer(Slideshow.PACKET_EXPORT, buffer);
    }

    private ItemStack getImageItem() {
        ItemStack itemStack = new ItemStack(Slideshow.IMAGE_ITEM, 1);
        itemStack.addTagElement("from_id", ByteTag.valueOf(this.mFromID));
        itemStack.addTagElement("location", StringTag.valueOf(this.mLocation));
        return itemStack;
    }

    //  服务端的数据包处理
    public static void handle(MinecraftServer minecraftServer, ServerPlayer serverPlayer, FriendlyByteBuf packet){
        ProjectorExportC2SPacket projectorExportPacket = new ProjectorExportC2SPacket(packet);
        minecraftServer.execute(() -> {
            if (ProjectorBlock.hasPermission(serverPlayer)) {
                ItemStack itemStack = projectorExportPacket.getImageItem();
                boolean bl = serverPlayer.inventory.add(itemStack);
                if (bl && itemStack.isEmpty()) {
                    itemStack.setCount(1);
                    ItemEntity itemEntity = serverPlayer.drop(itemStack, false);
                    if (itemEntity != null) {
                        itemEntity.makeFakeItem();
                    }

                    serverPlayer.level.playSound(null, serverPlayer.getX(), serverPlayer.getY(), serverPlayer.getZ(), SoundEvents.ITEM_PICKUP, SoundSource.PLAYERS, 0.2F, ((serverPlayer.getRandom().nextFloat() - serverPlayer.getRandom().nextFloat()) * 0.7F + 1.0F) * 2.0F);
                    serverPlayer.inventoryMenu.broadcastChanges();
                } else {
                    ItemEntity itemEntity = serverPlayer.drop(itemStack, false);
                    if (itemEntity != null) {
                        itemEntity.setNoPickUpDelay();
                        itemEntity.setOwner(serverPlayer.getUUID());
                    }
                }
                return;
            }
            GameProfile profile = serverPlayer.getGameProfile();
            Slideshow.LOGGER.debug(Utilities.MARKER, "Received illegal packet for projector export: player = {}", profile);
        });
    }
}
