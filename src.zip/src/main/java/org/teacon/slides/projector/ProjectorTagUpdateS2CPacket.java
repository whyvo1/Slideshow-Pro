package org.teacon.slides.projector;

import io.netty.buffer.Unpooled;
import net.fabricmc.fabric.api.networking.v1.PlayerLookup;
import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.block.entity.BlockEntity;
import org.teacon.slides.Registry;
import org.teacon.slides.Slideshow;
import org.teacon.slides.util.Utilities;

public class ProjectorTagUpdateS2CPacket {
    private final BlockPos mPos;
    private final CompoundTag mTag;

    public ProjectorTagUpdateS2CPacket(ProjectorBlockEntity entity) {
        this.mPos = entity.getBlockPos();
        this.mTag = new CompoundTag();
        entity.saveCompound(this.mTag);
    }

    public ProjectorTagUpdateS2CPacket(FriendlyByteBuf buffer) {
        this.mPos = buffer.readBlockPos();
        this.mTag = buffer.readNbt();
    }

    public void sendToClient(ServerLevel level) {
        FriendlyByteBuf buffer = new FriendlyByteBuf(Unpooled.buffer());
        buffer.writeBlockPos(mPos);
        buffer.writeNbt(this.mTag);
        for(ServerPlayer player : PlayerLookup.tracking(level, mPos)) {
            Registry.sendToPlayer(player, Slideshow.PACKET_TAG_UPDATE, buffer);
        }
    }

    public static void handle(Minecraft client, FriendlyByteBuf buffer) {
        ProjectorTagUpdateS2CPacket packet = new ProjectorTagUpdateS2CPacket(buffer);
        client.execute(() -> {
            if (client.level != null) {
                BlockEntity entity = client.level.getBlockEntity(packet.mPos);
                if(entity instanceof ProjectorBlockEntity entity1) {
                    if(packet.mTag != null) {
                        entity1.loadCompound(packet.mTag);
                        return;
                    }
                }
            }
            Slideshow.LOGGER.debug(Utilities.MARKER, "Received illegal packet for projector tag update");
        });
    }
}
