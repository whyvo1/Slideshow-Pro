package org.teacon.slides.projector;


/**
 * 投影仪的图片来源枚举
 */
public enum SourceType {
    URL,
    ResourceID,
    ContainerBlock
}
