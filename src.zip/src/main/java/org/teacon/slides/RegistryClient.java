package org.teacon.slides;

import net.fabricmc.fabric.api.blockrenderlayer.v1.BlockRenderLayerMap;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendereregistry.v1.BlockEntityRendererRegistry;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderDispatcher;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderer;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityType;
import org.teacon.slides.util.NetworkUtilities;

import java.util.function.Consumer;
import java.util.function.Function;

public class RegistryClient {

	public static void registerBlockRenderType(RenderType type, Block block) {
		BlockRenderLayerMap.INSTANCE.putBlock(block, type);
	}

	public static <T extends BlockEntity> void registerTileEntityRenderer(BlockEntityType<T> type, Function<BlockEntityRenderDispatcher, BlockEntityRenderer<? super T>> function) {
		BlockEntityRendererRegistry.INSTANCE.register(type, function);
	}

	public static void registerNetworkReceiver(ResourceLocation resourceLocation, NetworkUtilities.S2CPacketCallback packetCallback) {
		ClientPlayNetworking.registerGlobalReceiver(resourceLocation, (client, handler, buf, sender) -> {
			packetCallback.packetCallback(client, buf);
		});
	}

	public static void registerClientStoppingEvent(Consumer<Minecraft> consumer) {
		ClientLifecycleEvents.CLIENT_STOPPING.register(consumer::accept);
	}

	public static void registerTickEvent(Consumer<Minecraft> consumer) {
		ClientTickEvents.START_CLIENT_TICK.register(consumer::accept);
	}

	public static void sendToServer(ResourceLocation id, FriendlyByteBuf packet) {
		ClientPlayNetworking.send(id, packet);
	}
}
