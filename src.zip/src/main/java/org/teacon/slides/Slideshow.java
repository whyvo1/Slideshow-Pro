package org.teacon.slides;

import net.fabricmc.api.ModInitializer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntityType;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.teacon.slides.item.FlipperItem;
import org.teacon.slides.item.ImageItem;
import org.teacon.slides.projector.ProjectorBlock;
import org.teacon.slides.projector.ProjectorBlockEntity;
import org.teacon.slides.projector.ProjectorExportC2SPacket;
import org.teacon.slides.projector.ProjectorAfterUpdateC2SPacket;

public class Slideshow implements ModInitializer {
	public static final String ID = "slide_show";
	public static final Logger LOGGER = LogManager.getLogger(ID);
	public static final ResourceLocation PACKET_UPDATE = new ResourceLocation(ID, "update");
	public static final ResourceLocation PACKET_OPEN_GUI = new ResourceLocation(ID, "open_gui");
	public static final ResourceLocation PACKET_EXPORT = new ResourceLocation(ID, "export");
	public static final ResourceLocation PACKET_FLIP_BACK = new ResourceLocation(ID, "flip_back");
	public static final ResourceLocation PACKET_TAG_UPDATE = new ResourceLocation(ID, "tag_update");


	public static Item IMAGE_ITEM;
	public static Item FLIPPER_ITEM;

	public static Block PROJECTOR_BLOCK;
	public static BlockEntityType<ProjectorBlockEntity> PROJECTOR_BLOCK_ENTITY;

	@Override
	public void onInitialize() {
		IMAGE_ITEM = registerItem("image", new ImageItem(new Item.Properties()
				.tab(CreativeModeTab.TAB_MISC)
				.stacksTo(1)
		));
		Slideshow.FLIPPER_ITEM = registerItem("flipper", new FlipperItem(new Item.Properties()
				.tab(CreativeModeTab.TAB_MISC)
				.stacksTo(1)
		));
		Slideshow.PROJECTOR_BLOCK = registerBlockAndItem("projector", new ProjectorBlock());
		Slideshow.PROJECTOR_BLOCK_ENTITY = net.minecraft.core.Registry.register(net.minecraft.core.Registry.BLOCK_ENTITY_TYPE, new ResourceLocation(Slideshow.ID, "projector"), BlockEntityType.Builder.of(ProjectorBlockEntity::new, Slideshow.PROJECTOR_BLOCK).build(null));
		Registry.registerNetworkReceiver(PACKET_UPDATE, ProjectorAfterUpdateC2SPacket::handle);
		Registry.registerNetworkReceiver(PACKET_EXPORT, ProjectorExportC2SPacket::handle);
		Registry.registerNetworkReceiver(PACKET_FLIP_BACK, FlipperItem::handleServerFlipBack);
	}

	private static Item registerItem(String path, Item item) {
		return net.minecraft.core.Registry.register(net.minecraft.core.Registry.ITEM, new ResourceLocation(Slideshow.ID, path), item);
	}

	private static Block registerBlockAndItem(String path, Block block) {
		Block block0 = net.minecraft.core.Registry.register(net.minecraft.core.Registry.BLOCK, new ResourceLocation(Slideshow.ID, path), block);
		net.minecraft.core.Registry.register(net.minecraft.core.Registry.ITEM, new ResourceLocation(Slideshow.ID, path), new BlockItem(block0, new Item.Properties().tab(CreativeModeTab.TAB_MISC)));
		return block0;
	}
}