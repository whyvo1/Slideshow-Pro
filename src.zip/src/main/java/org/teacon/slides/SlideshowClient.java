package org.teacon.slides;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.resource.ResourceManagerHelper;
import net.fabricmc.fabric.api.resource.SimpleSynchronousResourceReloadListener;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.packs.PackType;
import net.minecraft.server.packs.resources.ResourceManager;
import org.teacon.slides.projector.ProjectorScreen;
import org.teacon.slides.projector.ProjectorTagUpdateS2CPacket;
import org.teacon.slides.renderer.ProjectorRenderer;
import org.teacon.slides.renderer.SlideState;

public class SlideshowClient implements ClientModInitializer {

	@Override
	public void onInitializeClient() {
		RegistryClient.registerTileEntityRenderer(Slideshow.PROJECTOR_BLOCK_ENTITY, ProjectorRenderer::new);
		RegistryClient.registerBlockRenderType(RenderType.cutout(), Slideshow.PROJECTOR_BLOCK);
		RegistryClient.registerTickEvent(SlideState::tick);
		RegistryClient.registerClientStoppingEvent(SlideState::onPlayerLeft);
		RegistryClient.registerNetworkReceiver(Slideshow.PACKET_OPEN_GUI, ProjectorScreen::openScreen);
		RegistryClient.registerNetworkReceiver(Slideshow.PACKET_TAG_UPDATE, ProjectorTagUpdateS2CPacket::handle);

		ResourceManagerHelper.get(PackType.CLIENT_RESOURCES).registerReloadListener(new SimpleSynchronousResourceReloadListener() {
			private final ResourceLocation id = new ResourceLocation(Slideshow.ID, "client_reload");
			@Override
			public void onResourceManagerReload(ResourceManager resourceManager) {
				SlideState.clearCacheID();
			}

			@Override
			public ResourceLocation getFabricId() {
				return this.id;
			}
		});
	}
}
