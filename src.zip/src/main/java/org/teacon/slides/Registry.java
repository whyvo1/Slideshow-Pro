package org.teacon.slides;

import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import org.teacon.slides.util.NetworkUtilities;

public class Registry {

	public static void registerNetworkReceiver(ResourceLocation resourceLocation, NetworkUtilities.C2SPacketCallback packetCallback) {
		ServerPlayNetworking.registerGlobalReceiver(resourceLocation, (server, player, handler, buf, sender) -> {
			packetCallback.packetCallback(server, player, buf);
		});
	}

	public static void sendToPlayer(ServerPlayer player, ResourceLocation id, FriendlyByteBuf packet) {
		ServerPlayNetworking.send(player, id, packet);
	}
}
