package org.teacon.slides.util;

import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ClientboundSetTitlesPacket;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;
import org.apache.logging.log4j.Marker;
import org.apache.logging.log4j.MarkerManager;

import java.util.Collections;

public class Utilities {
    public static final Marker MARKER = MarkerManager.getMarker("Network");

    public static <T extends BlockEntity> BlockEntityType<T> getBlockEntityType(TileEntitySupplier<T> supplier, Block block) {
        return new BlockEntityType<>(supplier::supplier, Collections.singleton(block), null);
    }

    @FunctionalInterface
    public interface TileEntitySupplier<T extends BlockEntity> {
        T supplier();
    }

    public static void sendOverLayMessage(Player player, Component message) {
        if(player instanceof ServerPlayer serverPlayer) {
            serverPlayer.connection.send(new ClientboundSetTitlesPacket(ClientboundSetTitlesPacket.Type.ACTIONBAR, message));
        }
    }
}
