package org.teacon.slides.util;

import net.minecraft.network.chat.MutableComponent;
import net.minecraft.network.chat.TextComponent;
import net.minecraft.network.chat.TranslatableComponent;

public class Text {

	public static MutableComponent translatable(String text, Object... objects) {
		return new TranslatableComponent(text, objects);
	}

	public static MutableComponent literal(String text) {
		return new TextComponent(text);
	}
}
