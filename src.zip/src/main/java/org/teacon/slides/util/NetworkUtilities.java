package org.teacon.slides.util;

import net.minecraft.client.Minecraft;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;

public class NetworkUtilities {

	@FunctionalInterface
	public interface C2SPacketCallback {
		void packetCallback(MinecraftServer server, ServerPlayer player, FriendlyByteBuf packet);
	}

	@FunctionalInterface
	public interface S2CPacketCallback {
		void packetCallback(Minecraft client, FriendlyByteBuf packet);
	}
}
