package org.teacon.slides.item;

import com.mojang.authlib.GameProfile;
import io.netty.buffer.Unpooled;
import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.IntArrayTag;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import org.jetbrains.annotations.Nullable;
import org.teacon.slides.RegistryClient;
import org.teacon.slides.Slideshow;
import org.teacon.slides.util.Utilities;
import org.teacon.slides.util.Text;
import org.teacon.slides.projector.ProjectorBlock;
import org.teacon.slides.projector.ProjectorBlockEntity;

import java.util.List;

/**
 * 翻页笔
 */
public class FlipperItem extends Item {
    private static boolean keyAttackDown = false;
    private static boolean fooBl = false;


    public FlipperItem(Properties properties) {
        super(properties);
    }

//    @Override
//    public InteractionResult useOn(UseOnContext useOnContext) {
//        Level level = useOnContext.getLevel();
//        if(level.isClientSide()) {
//            return InteractionResult.SUCCESS;
//        }
//        ItemStack item = useOnContext.getItemInHand();
//        BlockPos pos = useOnContext.getClickedPos();
//
//        if(level.getBlockState(pos).getBlock() instanceof ProjectorBlock) {
//            item.addTagElement("projector", new IntArrayTag(new int[] { pos.getX(), pos.getY(), pos.getZ() }));
//        }
//        return InteractionResult.SUCCESS;
//    }

    // 尝试获取绑定的投影仪的位置
    public static int[] getProjectorPos(ItemStack stack) {
        if(!(stack.getItem() instanceof FlipperItem) || !stack.hasTag() || stack.getTag().getIntArray("projector") == null) {
            return null;
        }
        int[] intArray = stack.getTag().getIntArray("projector");
        if(intArray == null || intArray.length < 3) {
            return null;
        }
        return intArray;
    }

    // 设置绑定
    public static void setProjectorPos(ItemStack stack, @Nullable BlockPos pos) {
        if(!(stack.getItem() instanceof FlipperItem)) {
            return;
        }
        if(pos == null) {
            stack.removeTagKey("projector");
            return;
        }
        stack.addTagElement("projector", new IntArrayTag(new int[]{pos.getX(), pos.getY(), pos.getZ()}));
    }

    // 尝试对绑定的投影仪翻页
    public static boolean trySendFlip(Level level, Player player, ItemStack itemStack, boolean back, boolean init) {
        int[] pos = getProjectorPos(itemStack);
        if(pos == null) {
            Utilities.sendOverLayMessage(player, Text.translatable("info.slide_show.need_bound").withStyle(ChatFormatting.DARK_RED));
            //Minecraft.getInstance().gui.setOverlayMessage(Text.translatable("info.slide_show.need_bound").withStyle(ChatFormatting.DARK_RED), false);
            return false;
        }
        BlockEntity entity = level.getBlockEntity(new BlockPos(pos[0], pos[1], pos[2]));
        if(!(entity instanceof ProjectorBlockEntity entity1)) {
            Utilities.sendOverLayMessage(player, Text.translatable("info.slide_show.binding_lost").withStyle(ChatFormatting.DARK_RED));
            //Minecraft.getInstance().gui.setOverlayMessage(Text.translatable("info.slide_show.binding_lost").withStyle(ChatFormatting.DARK_RED), false);
            setProjectorPos(itemStack, null);
            return false;
        }
        if(!ProjectorBlock.hasPermission((ServerPlayer) player)) {
            return false;
        }
        if(!entity1.canFlip()) {
            return false;
        }
        if(init) {
            entity1.needInitContainer = true;
            Utilities.sendOverLayMessage(player, Text.translatable("info.slide_show.initialized").withStyle(ChatFormatting.AQUA));
            return true;
        }
        entity1.needHandleReadImage = true;
        if(back) {
            entity1.flipBack = true;
        }
        Utilities.sendOverLayMessage(player, Text.translatable("info.slide_show.slide_flipped").withStyle(ChatFormatting.AQUA));
        //Minecraft.getInstance().gui.setOverlayMessage(Text.translatable("info.slide_show.slide_flipped").withStyle(ChatFormatting.AQUA), false);
        return true;
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand interactionHand) {
        ItemStack itemStack = player.getItemInHand(interactionHand);
        if(level.isClientSide()) {
            return InteractionResultHolder.sidedSuccess(itemStack, level.isClientSide());
        }
        if(trySendFlip(level, player, itemStack, false, player.isShiftKeyDown())){
            return InteractionResultHolder.sidedSuccess(itemStack, true);
        }

        return InteractionResultHolder.pass(itemStack);
    }

    @Override
    public void inventoryTick(ItemStack itemStack, Level level, Entity entity, int slot, boolean selected) {
        super.inventoryTick(itemStack, level, entity, slot, selected);
        if(level.isClientSide() && selected) {
            keyAttackDown = Minecraft.getInstance().options.keyAttack.isDown();
            if(keyAttackDown != fooBl) {
                if(keyAttackDown) {
                    sendServerFlipBack(slot);
                }
                fooBl = keyAttackDown;
            }
        }
    }

    @Override
    public void appendHoverText(ItemStack itemStack, @Nullable Level level, List<Component> list, TooltipFlag tooltipFlag) {
        int[] pos = getProjectorPos(itemStack);
        if(pos == null) {
            list.add(Text.translatable("item.slide_show.flipper.tooltip.not_bound").withStyle(ChatFormatting.RED));
            list.add(Text.translatable("item.slide_show.flipper.tooltip.not_bound1"));
            super.appendHoverText(itemStack, level, list, tooltipFlag);
            return;
        }
        list.add(Text.translatable("item.slide_show.flipper.tooltip.bound", pos[0], pos[1], pos[2]).withStyle(ChatFormatting.AQUA));
        super.appendHoverText(itemStack, level, list, tooltipFlag);
    }

    // 翻页的C2S
    private static void sendServerFlipBack(int i) {
        FriendlyByteBuf buffer = new FriendlyByteBuf(Unpooled.buffer());
        buffer.writeInt(i);
        RegistryClient.sendToServer(Slideshow.PACKET_FLIP_BACK, buffer);
    }

    // 服务端处理数据包
    public static void handleServerFlipBack(MinecraftServer minecraftServer, ServerPlayer serverPlayer, FriendlyByteBuf packet) {
        int i = packet.readInt();
        minecraftServer.execute(() -> {
            ItemStack itemStack = serverPlayer.inventory.getItem(i);
            if(!(itemStack.getItem() instanceof FlipperItem && trySendFlip(serverPlayer.getLevel(), serverPlayer, itemStack, true, false))){
                GameProfile profile = serverPlayer.getGameProfile();
                Slideshow.LOGGER.debug(Utilities.MARKER, "Received illegal packet for flip back: player = {}", profile);
            }
        });
    }

    @Override
    public boolean canAttackBlock(BlockState blockState, Level level, BlockPos blockPos, Player player) {
        return false;
    }
}
