package org.teacon.slides.item;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.Nullable;
import org.teacon.slides.util.Text;

import java.util.List;

/**
 * 图片物品
 */
public class ImageItem extends Item {

    public ImageItem(Properties properties) {
        super(properties);
    }

    @Override
    public void appendHoverText(ItemStack itemStack, @Nullable Level level, List<Component> list, TooltipFlag tooltipFlag) {
        if(!itemStack.hasTag() || itemStack.getTag().getString("location") == null) {
            list.add(Text.translatable("item.slide_show.image.tooltip.no_properties").withStyle(ChatFormatting.DARK_RED));
            super.appendHoverText(itemStack, level, list, tooltipFlag);
            return;
        }
        list.add(Text.translatable(itemStack.getTag().getBoolean("from_id") ? "item.slide_show.image.tooltip.id" : "item.slide_show.image.tooltip.url").withStyle(ChatFormatting.AQUA));
        list.add(Text.literal(itemStack.getTag().getString("location")).withStyle(ChatFormatting.AQUA));
        super.appendHoverText(itemStack, level, list, tooltipFlag);
    }
}
