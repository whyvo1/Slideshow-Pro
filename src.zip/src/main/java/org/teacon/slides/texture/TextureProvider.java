package org.teacon.slides.texture;

import org.jetbrains.annotations.NotNull;
import org.teacon.slides.renderer.SlideRenderType;

/**
 * 纹理提供器接口
 */
public interface TextureProvider extends AutoCloseable {

	@NotNull
	SlideRenderType updateAndGet(long tick, float partialTick);

	int getWidth();

	int getHeight();

	@Override
	void close();
}
